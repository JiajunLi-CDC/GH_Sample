﻿using CurlyKale._03_Mesh.ReuseCauculate;
using Grasshopper.Kernel;
using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace CurlyKale._03_Mesh
{
    public class GhcReuseCauculate : GH_Component
    {

        #region Register Node
        public GhcReuseCauculate()
          : base("ReuseCauculateSolver", "RCSolver", "基于力学模拟的杆件重复利用迭代优化器", "CurlyKale", "03 MeshGrowth")
        {
        }
        public override GH_Exposure Exposure
        {
            get
            {
                return GH_Exposure.secondary;
            }
        }

        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                return Properties.Resources.ReuseOptimize;
            }
        }

        public override Guid ComponentGuid
        {
            get
            {
                return new Guid("886d2347-c981-46d8-bdca-b8ca8c9e9096");
            }
        }
        #endregion


        #region Inputs/Outputs

        MeshRodOptimize_System _MyRodSystem;
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddMeshParameter("starting Mesh", "startingMesh", "初始网格", GH_ParamAccess.item);
            pManager.AddBooleanParameter("reset", "reset", "重置优化", GH_ParamAccess.item);
            pManager.AddIntegerParameter("rod_cluster", "Rod_num", "聚类的种数量", GH_ParamAccess.item, 2);
            pManager.AddNumberParameter("tolerance1", "t1", "每种聚类的最短构件与最长构件之间的最大长度差", GH_ParamAccess.item, 0.1);
            pManager.AddNumberParameter("tolerance2", "t2", "每种聚类的最短构件之间的最小长度差，用于控制聚类的种数", GH_ParamAccess.item, 1.0);
            pManager.AddNumberParameter("minAngle", "minAngle", "最小角度控制", GH_ParamAccess.item, Math.PI);
            pManager.AddIntegerParameter("lengthWeight", "lengthWeight", "长度权重", GH_ParamAccess.item, 1);
            pManager.AddIntegerParameter("angleWeight", "AngleWeight", "角度权重", GH_ParamAccess.item, 1);
        }

        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.Register_GenericParam("GyresMesh", "GeMesh", "优化后的Gyres网格", GH_ParamAccess.item);
            pManager.Register_GenericParam("Lines", "Lines", "所有的杆件线段");
            pManager.AddIntegerParameter("RodType", "RodType", "杆件分类情况", GH_ParamAccess.list);
            pManager.AddNumberParameter("Expect_length", "Ep_Len", "期望的长度", GH_ParamAccess.list);
            pManager.Register_GenericParam("State", "State", "优化状态");
        }

        #endregion


        #region Solution
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            bool iReset = true;
            Mesh iStartingMesh = null;
            int iRod_cluster_num = 0;
            double iMinAngle = 0;
            int iLengthWeight = 0;
            int iAngleWeight = 0;
            double iTolerance1 = 0;
            double iTolerance2 = 0;
            string State;

            DA.GetData("starting Mesh", ref iStartingMesh);
            DA.GetData("reset", ref iReset);
            DA.GetData("rod_cluster", ref iRod_cluster_num);
            DA.GetData("tolerance1", ref iTolerance1);
            DA.GetData("tolerance2", ref iTolerance2);
            DA.GetData("minAngle", ref iMinAngle);
            DA.GetData("lengthWeight", ref iLengthWeight);
            DA.GetData("angleWeight", ref iAngleWeight);

            if (iStartingMesh == null)
            {
                AddRuntimeMessage(GH_RuntimeMessageLevel.Warning, "Failed to collect any valid mesh.");
            }

            //=============================================================================================

            if (iReset || _MyRodSystem == null)
            {
                _MyRodSystem = new MeshRodOptimize_System(iStartingMesh, iRod_cluster_num, iTolerance1, iMinAngle, iLengthWeight, iAngleWeight);
            }

            _MyRodSystem.rodWeight = iLengthWeight;
            _MyRodSystem.rodAngleWeight = iAngleWeight;   //可以实时修改权重
            _MyRodSystem.tolerance = iTolerance1;

            //=============================================================================================
            _MyRodSystem.refreshData();
            _MyRodSystem.state = _MyRodSystem.CauculateRodState();


            double min_type_different = _MyRodSystem.GetRod_type_difference(_MyRodSystem.GetFinal_Type_lenth());
            if (_MyRodSystem.state == true)    //如果优化结束但是聚类的最小差距小于阈值t2,则说明有两个聚类过于相似，聚类种数减少1并继续进行优化
            {
                if (min_type_different < iTolerance2 && _MyRodSystem.Rod_cluster_num > 2)
                {
                    _MyRodSystem.Rod_cluster_num -= 1;
                    _MyRodSystem.state = false;
                }
            }


            if (_MyRodSystem.state == false)
            {
                _MyRodSystem.RodOptimize();
                _MyRodSystem.RodAngleOptimize();

                _MyRodSystem.UpdateVertexPosition();

                _MyRodSystem.getExpected_Length_ByEdge(_MyRodSystem.Rod_cluster_num, 5);  //根据现有长度的分组区间情况获取每根杆件的期望长度
            }


            if (_MyRodSystem.state == true)
            {
                State = "Done！_优化已经完成............当前单个聚类中杆件最大误差MaxDifference=" + _MyRodSystem.maxDifference + "..........杆件最小角度MinAngle=" + _MyRodSystem.minRodAngle + "...........当前所有类型聚类之间最小差别MinDifference=" + min_type_different + "...........当前k=" + _MyRodSystem.Rod_cluster_num;
            }
            else
            {
                State = "Solvering！_优化正在进行中............当前单个聚类中杆件最大误差MaxDifference=" + _MyRodSystem.maxDifference + "..........当前杆件最小角度MinAngle=" + _MyRodSystem.minRodAngle + "当前所有类型聚类之间最小差别MinDifference=" + min_type_different + "...........当前k=" + _MyRodSystem.Rod_cluster_num; ;
            }

            DA.SetData("GyresMesh", _MyRodSystem.mesh);
            DA.SetDataList("Lines", _MyRodSystem.GetAllRodLines());
            DA.SetDataList("RodType", _MyRodSystem.GetRodType());
            DA.SetDataList("Expect_length", _MyRodSystem.GetExpected_Length());
            DA.SetData("State", State);

        }


        #endregion

    }
}