﻿using Grasshopper.Kernel;
using Hsy.GyresMesh;
using Rhino.Geometry;
using System;
using System.Collections.Generic;
using Hsy.GyresMeshGH;

namespace CurlyKale._03_Mesh.MeshGrowth
{
    public class GhcToRhinoMesh : GH_Component
    {
        #region Register Node
        public GhcToRhinoMesh()
        : base("ToRhinoMesh", "RhMesh", "将GyresMesh转化为RhinoMesh", "CurlyKale", "03 MeshGrowth")
        {
        }

        protected override System.Drawing.Bitmap Icon
        {
            get
            {

                return Properties.Resources.ToRhinoMesh;
            }
        }

        public override GH_Exposure Exposure
        {
            get
            {
                return GH_Exposure.secondary;
            }
        }

        public override Guid ComponentGuid
        {
            get
            {
                return new Guid("91a4fcc1-53bc-4acd-a0f4-7641f44b5abc");
            }
        }
        #endregion


        #region Inputs/Outputs
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddGenericParameter("GyresMesh", "GeMesh", "Gyres网格", GH_ParamAccess.item);
        }


        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.Register_GenericParam("RhinoMesh", "RhMesh", "Rhino网格", GH_ParamAccess.item);
        }
        #endregion


        #region Solution
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            GE_Mesh iGyresMesh = null;

            DA.GetData("GyresMesh", ref iGyresMesh);

            if (iGyresMesh == null)
            {
                AddRuntimeMessage(GH_RuntimeMessageLevel.Warning, "Failed to collect any valid GyresMesh.");
            }

            //=============================================================================================

            Mesh RhinoMesh = new Mesh();
            if (iGyresMesh != null)
            {
                RhinoMesh = iGyresMesh.ToRhinoMesh();
            }


            DA.SetData("RhinoMesh", RhinoMesh);
        }
        #endregion


    }
}