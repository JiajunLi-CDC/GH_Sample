﻿using Grasshopper;
using Grasshopper.Kernel;
using Grasshopper.Kernel.Data;
using Hsy.GyresMesh;
using Hsy.GyresMeshGH;
using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace CurlyKale._03_Mesh
{
    public class GhcGetPolygonParameters : GH_Component
    {
        public GhcGetPolygonParameters()
          : base("GetPolygonParameters", "GetPolygonParameters", "获取网格各个多边形面的形态特征参数并且归一化（边长、角度、面积）", "CurlyKale", "03 MeshGrowth")
        {
        }
        public override GH_Exposure Exposure
        {
            get
            {
                return GH_Exposure.tertiary;
            }
        }

        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddMeshParameter("Mesh", "Mesh", "多边形网格List", GH_ParamAccess.list);
        }


        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddNumberParameter("Outputs", "Outputs", "The list of outputs", GH_ParamAccess.tree);
        }


        protected override void SolveInstance(IGH_DataAccess DA)
        {
            List<Mesh> iMeshes = new List<Mesh>();

            DA.GetDataList("Mesh", iMeshes);

            //------------------------------------------------------------------------

            List<GE_Mesh> GMeshes = new List<GE_Mesh>();
            for (int i = 0; i < iMeshes.Count; i++)
            {
                GE_Mesh Gmesh = iMeshes[i].ToGyresMesh();
                GMeshes.Add(Gmesh);
            }

            DataTree<double> outputs = new DataTree<double>();
            for (int i = 0; i < GMeshes.Count; i++)
            {
                // list of lists 
                List<List<double>> outputList = GMeshes[i].GetFaces_parameter();
                for (int j = 0; j < outputList.Count; j++)
                {
                    GH_Path path = new GH_Path(i, j);             
                    outputs.AddRange(outputList[j], path);                   
                }
            }

            //Output
            DA.SetDataTree(0, outputs);
        }


        protected override System.Drawing.Bitmap Icon
        {
            get
            {

                return Properties.Resources.FaceParameters_icon;
            }
        }


        public override Guid ComponentGuid
        {
            get
            {
                return new Guid("9899ca1a-b75b-4a56-b1a1-b78aea6d943e");
            }
        }
    }
}