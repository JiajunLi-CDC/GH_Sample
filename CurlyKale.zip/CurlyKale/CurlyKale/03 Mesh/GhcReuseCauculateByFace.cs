﻿using CurlyKale._03_Mesh.ReuseCauculate;
using Grasshopper.Kernel;
using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace CurlyKale._03_Mesh
{
    public class GhcReuseCauculateByFace : GH_Component
    {

        #region Register Node
        public GhcReuseCauculateByFace()
          : base("ReuseCauculateSolver_ByPanel", "RCSolver", "基于力学模拟的杆件面板重复利用迭代优化器", "CurlyKale", "03 MeshGrowth")
        {
        }
        public override GH_Exposure Exposure
        {
            get
            {
                return GH_Exposure.secondary;
            }
        }

        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                return Properties.Resources.ReuseOptimaze_byFace_icon;
            }
        }

        public override Guid ComponentGuid
        {
            get
            {
                return new Guid("886d2347-c981-46d8-bdca-b8ca8c9e9126");
            }
        }
        #endregion


        #region Inputs/Outputs

        MeshRodOptimize_System _MyRodSystem;
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddMeshParameter("starting Mesh", "startingMesh", "初始网格", GH_ParamAccess.item);
            pManager.AddBooleanParameter("reset", "reset", "重置优化", GH_ParamAccess.item);
            pManager.AddIntegerParameter("rod_cluster", "rod_num", "杆件聚类的种数量", GH_ParamAccess.item, 2);
            pManager.AddIntegerParameter("rod_minCluster", "rod_min", "杆件聚类的最小数量", GH_ParamAccess.item, 2);
            pManager.AddIntegerParameter("panel_cluster", "panel_num", "面板聚类的种数量", GH_ParamAccess.item, 2);
            pManager.AddNumberParameter("tolerance1", "t1", "每种聚类的最短构件与最长构件之间的最大长度差", GH_ParamAccess.item, 0.1);
            pManager.AddNumberParameter("tolerance2", "t2", "每种聚类的最短构件之间的最小长度差，用于控制聚类的种数", GH_ParamAccess.item, 1.0);
            pManager.AddNumberParameter("minRodAngle", "minRodAngle", "最小杆件角度控制", GH_ParamAccess.item, Math.PI * 0.35);
            pManager.AddNumberParameter("minFaceAngle", "minFaceAngle", "最小面板角度控制", GH_ParamAccess.item, Math.PI * 0.35);
            pManager.AddIntegerParameter("rodWeight", "rodWeight", "杆件长度权重", GH_ParamAccess.item, 1);
            pManager.AddIntegerParameter("panelWeight", "panelWeight", "面板权重", GH_ParamAccess.item, 1);
            pManager.AddIntegerParameter("rodAngleWeight", "rodAngleWeight", "杆件角度权重", GH_ParamAccess.item, 1);
            pManager.AddIntegerParameter("faceAngleWeight", "faceAngleWeight", "面板角度权重", GH_ParamAccess.item, 1);
           
        }

        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.Register_GenericParam("GyresMesh", "GeMesh", "优化后的Gyres网格", GH_ParamAccess.item);
            pManager.Register_GenericParam("Lines", "Lines", "所有的杆件线段");
            pManager.AddIntegerParameter("RodType", "RodType", "杆件分类情况", GH_ParamAccess.list);
            pManager.AddIntegerParameter("PanelType", "PanelType", "面板分类情况", GH_ParamAccess.list);
            pManager.AddNumberParameter("Expect_length", "Ep_Len", "期望的长度", GH_ParamAccess.list);
            pManager.Register_GenericParam("State", "State", "优化状态");
            pManager.Register_GenericParam("Debug", "Debug", "Debug");
        }

        #endregion


        #region Solution
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            bool iReset = true;
            Mesh iStartingMesh = null;
            int iRod_cluster_num = 0;
            int iRod_minCluster_num = 0;
            int iPanel_cluster_num = 0;
            double iMinRodAngle = 0;
            double iMinFaceAngle = 0;
            int iRodWeight = 0;
            int iRodAngleWeight = 0;
            int iPanelWeight = 0;
            int iFaceAngleWeight = 0;
            double iTolerance1 = 0;
            double iTolerance2 = 0;
            string State;

            DA.GetData("starting Mesh", ref iStartingMesh);
            DA.GetData("reset", ref iReset);
            DA.GetData("rod_cluster", ref iRod_cluster_num);
            DA.GetData("rod_minCluster", ref iRod_minCluster_num);
            DA.GetData("panel_cluster", ref iPanel_cluster_num);
            DA.GetData("tolerance1", ref iTolerance1);
            DA.GetData("tolerance2", ref iTolerance2);
            DA.GetData("minRodAngle", ref iMinRodAngle);
            DA.GetData("minFaceAngle", ref iMinFaceAngle);
            DA.GetData("rodWeight", ref iRodWeight);
            DA.GetData("panelWeight", ref iPanelWeight);
            DA.GetData("rodAngleWeight", ref iRodAngleWeight);
            DA.GetData("faceAngleWeight", ref iFaceAngleWeight);
           

            if (iStartingMesh == null)
            {
                AddRuntimeMessage(GH_RuntimeMessageLevel.Warning, "Failed to collect any valid mesh.");
            }

            //=============================================================================================

            if (iReset || _MyRodSystem == null)
            {
                _MyRodSystem = new MeshRodOptimize_System(iStartingMesh, iRod_cluster_num, iPanel_cluster_num, iTolerance1, iMinRodAngle, iMinFaceAngle, iRodWeight, iFaceAngleWeight, iRodAngleWeight, iPanelWeight);
            }

            _MyRodSystem.rodWeight = iRodWeight;    //可以实时修改权重     
            _MyRodSystem.panelWeight = iPanelWeight;
            _MyRodSystem.rodAngleWeight = iRodAngleWeight;       
            _MyRodSystem.faceAngleWeight = iFaceAngleWeight;

            _MyRodSystem.tolerance = iTolerance1;


            //=============================================================================================
            _MyRodSystem.refreshData();
            _MyRodSystem.state = _MyRodSystem.CauculateRodState();



            double min_type_different = _MyRodSystem.GetRod_type_difference(_MyRodSystem.GetFinal_Type_lenth());
            if (_MyRodSystem.state == true)    //如果优化结束但是聚类的最小差距小于阈值t2,则说明有两个聚类过于相似，聚类种数减少1并继续进行优化
            {
                if (min_type_different < iTolerance2 && _MyRodSystem.Rod_cluster_num > iRod_minCluster_num)
                {
                    _MyRodSystem.Rod_cluster_num -= 1;
                    _MyRodSystem.state = false;
                }
            }


            if (_MyRodSystem.state == false)
            {
                _MyRodSystem.RodOptimize();
                _MyRodSystem.RodAngleOptimize();
                _MyRodSystem.FaceAngleOptimize();
                _MyRodSystem.PanelOptimize();

                _MyRodSystem.UpdateVertexPosition();

                _MyRodSystem.getExpected_Length_ByEdge(_MyRodSystem.Rod_cluster_num, 5);  //根据现有长度的分组区间情况获取每根杆件的期望长度
                _MyRodSystem.getExpected_Length_ByFace(_MyRodSystem.Panel_cluster_num, 5);
            }


            if (_MyRodSystem.state == true)
            {
                State = "Done！_优化已经完成............当前单个聚类中杆件最大误差MaxDifference=" + _MyRodSystem.maxDifference + "...........杆件所有类型聚类之间最小差别MinDifference=" + min_type_different +
                    "...........当前杆件k=" + _MyRodSystem.Rod_cluster_num + "...........当前面板k2=" + _MyRodSystem.Panel_cluster_num +
                    "..........杆件最小角度MinAngle=" + _MyRodSystem.minRodAngle + "...........面板最小角度MinFaceAngle=" + _MyRodSystem.minFaceAngle;
            }
            else
            {
                State = "Solvering！_优化正在进行中............当前单个聚类中杆件最大误差MaxDifference=" + _MyRodSystem.maxDifference + "...........当前所有类型聚类之间最小差别MinDifference=" + min_type_different +
                    "...........当前杆件k1=" + _MyRodSystem.Rod_cluster_num + "...........当前面板k2=" + _MyRodSystem.Panel_cluster_num + 
                    "..........当前杆件最小角度MinRodAngle=" + _MyRodSystem.minRodAngle + "...........当前面板最小角度MinFaceAngle=" + _MyRodSystem.minFaceAngle;
            }

            DA.SetData("GyresMesh", _MyRodSystem.mesh);
            DA.SetDataList("Lines", _MyRodSystem.GetAllRodLines());
            DA.SetDataList("RodType", _MyRodSystem.GetRodType());
            DA.SetDataList("PanelType", _MyRodSystem.GetPanelType());
            DA.SetDataList("Expect_length", _MyRodSystem.GetExpected_Length());
            DA.SetData("State", State);
            DA.SetDataList("Debug", _MyRodSystem.Debug);

        }


        #endregion

    }
}