﻿using CurlyKale._03_Mesh.ReuseCauculate;
using Grasshopper;
using Grasshopper.Kernel;
using Grasshopper.Kernel.Data;
using Grasshopper.Kernel.Types;
using Rhino.Geometry;
using System;
using System.Collections.Generic;

namespace CurlyKale._03_Mesh
{
    public class GhcSortListByMinValue : GH_Component
    {      
        public GhcSortListByMinValue()
           : base("SortListByMinValue", "SortListByMinValue", "从List的最小项从新开始算起", "CurlyKale", "03 MeshGrowth")
        {
        }
    
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddNumberParameter("InputsList", "Inputs", "The list of inputs.", GH_ParamAccess.tree);
        }
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddNumberParameter("Outputs", "Outputs", "The list of outputs", GH_ParamAccess.tree);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            //Variables
            GH_Structure<GH_Number> inputs = new GH_Structure<GH_Number>();

            DA.GetDataTree<GH_Number>("InputsList", out inputs);

            // list of lists
            List<List<double>> inputList = new List<List<double>>();

            // input list of lists from tree
            for (int i = 0; i < inputs.Branches.Count; i++)
            {
                List<double> list = new List<double>(0);
                List<GH_Number> branch = inputs.Branches[i];
                foreach (GH_Number num in branch)
                {
                    list.Add(num.Value);
                }

                inputList.Add(list);
            }

            inputList=inputList.StartFromMinValue();

            DataTree<double> outputs = new DataTree<double>();
            for (int i = 0; i < inputs.Branches.Count; i++)
            {
                GH_Path path = inputs.get_Path(i);
                outputs.AddRange(inputList[i], path);
            }


            //Output
            DA.SetDataTree(0, outputs);
        }


        protected override System.Drawing.Bitmap Icon
        {
            get
            {               
                return null;
            }
        }

        public override Guid ComponentGuid
        {
            get
            {
                return new Guid("af2c58a6-6f91-4c57-b028-475aa7e43165");
            }
        }
    }
}