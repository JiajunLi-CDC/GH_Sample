﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Rhino.Geometry;
using Hsy.GyresMesh;
using Hsy.Geo;

namespace CurlyKale._03_Mesh.ReuseCauculate
{
    public class Rod
    {
        double original_length;
        public double expect_length_ByEdge = 0;
        public List<double> expect_lengthList_ByFace;
        GE_Halfedge edge;
        public GE_Vertex startVertex;
        public GE_Vertex endVertex;

        public int index;  //杆件编号
        String type;  //构件种类

        public Rod(int index, GE_Halfedge edge)
        {
            this.index = index;
            this.edge = edge;

            original_length = this.edge.GetLength();
            startVertex = this.edge.GetStart();
            endVertex = this.edge.GetEnd();

        }

        public double getlength()  //获取杆件当前的长度
        {
            return edge.GetLength();
        }

        public GE_Halfedge getHalfedge()  //获取杆件对应半边
        {
            return edge;
        }

        public HS_Vector getLengthConstraint_MoveVector(double expect_length)  //获取每次迭代获取长度约束所需的向量
        {
            HS_Vector len = HS_Vector.sub(endVertex, startVertex);
            HS_Vector move = new HS_Vector(0, 0, 0);

            if (len.GetLength() < expect_length - 0.00001 || len.GetLength() > expect_length + 0.00001)
            {
                move = HS_Vector.mul(len, 0.5 * (len.GetLength() - expect_length) / len.GetLength());    //如果两点距离小于碰撞距离则扩张到规定距离,如果两点距离大于碰撞距离则收缩到规定距离
                //move = HS_Vector.mul(len, 0.5 * (1 - Math.Sqrt(expect_length / len.GetLength())));
            }

            return move;
        }
    }
}
