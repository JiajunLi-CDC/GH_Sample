﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hsy.GyresMesh;
using Hsy.Geo;
using Hsy.GyresMeshGH;

namespace CurlyKale._03_Mesh.ReuseCauculate
{
    public class Panel
    {
        GE_Face face;  //对应的网格面
        List<Rod> PanelConnectRods;  //相连的杆件

        public List<double> expected_length;   //记录聚类平均边长，按照从小最小边开始的逆时针顺序记录

        public List<double> panel_Lengths;  //记录边长，按照从最小边开始的逆时针顺序记录
        public List<double> panel_angles;  //记录角度，按照从最小角度开始的逆时针顺序记录
        public List<double> panel_area;  //记录边长

        public int similarPanel_Count = 0;

        int index;  //面板编号
        String type;  //面板种类

        public Panel(int index, GE_Face face, List<Rod> PanelConnectRods)
        {
            this.face = face;
            this.index = index;
            this.PanelConnectRods = PanelConnectRods;
            expected_length = new List<double>();
        }

        public GE_Face getFace()
        {
            return this.face;
        }
        public List<Rod> getRods()
        {
            return this.PanelConnectRods;
        }

        public void RefreshParameters()
        {
            List<double> eachLen_parameter = new List<double>();

            //===============================================记录边长

            for (int i = 0; i < face.GetFaceHalfedges().Count; i++)
            {
                GE_Halfedge edge = face.GetFaceHalfedges()[i];
                double n = edge.GetLength();
                eachLen_parameter.Add(n);
            }
            panel_Lengths = eachLen_parameter.StartFromMinValue();

            //===============================================重新排序对应的Rods

            for (int i = 0; i < PanelConnectRods.Count; i++)
            {
                if (PanelConnectRods[i].getlength() == panel_Lengths[0])
                {
                    List<Rod> L1 = PanelConnectRods.Skip(i).ToList();
                    List<Rod> L2 = PanelConnectRods.Take(i).ToList();

                    L1.AddRange(L2);
                    PanelConnectRods = L1;
                    break;
                }
            }

            //===============================================记录角度         

            List<double> eachAngle_parameter = new List<double>();
            for (int i = 0; i < face.GetFaceHalfedges().Count; i++)
            {
                GE_Halfedge edge1 = face.GetFaceHalfedges()[i];
                GE_Halfedge edge2;
                if (i == face.GetFaceHalfedges().Count - 1)
                {
                    edge2 = face.GetFaceHalfedges()[0];
                }
                else
                {
                    edge2 = face.GetFaceHalfedges()[i + 1];
                }

                HS_Vector n1 = edge1.GetStartPosition();
                HS_Vector n2 = edge1.GetEndPosition();
                HS_Vector n3 = edge2.GetStartPosition();
                HS_Vector n4 = edge2.GetEndPosition();

                HS_Vector v1 = HS_Vector.sub(n1, n2);
                HS_Vector v2 = HS_Vector.sub(n4, n3);

                double angle = HS_Vector.angle(v1, v2);
                eachAngle_parameter.Add(angle);
            }

            panel_angles = eachAngle_parameter.StartFromMinValue();

            //===============================================记录面积，这里当面为三角形时以三角形的海伦公式代替，只能适用三角形网格    

            List<double> eachArea_parameter = new List<double>();
            double area = 0;

            if (face.GetFaceVertices().Count == 3)
            {
                //Halen method for triangle
                double n1 = panel_Lengths[0];
                double n2 = panel_Lengths[1];
                double n3 = panel_Lengths[2];
                double s = 0.5 * (n1 + n2 + n3);
                area = Math.Sqrt(s * (s - n1) * (s - n2) * (s - n3));
            }
            else
            {
                List<HS_Coord> points = new List<HS_Coord>();
                for (int j = 0; j < face.GetFaceVertices().Count; j++)
                {
                    points.Add(face.GetFaceVertices()[j]);
                }
                HS_Polygon poly = new HS_Polygon(points);
                area = Math.Abs(poly.GetSignedArea());
            }

            eachArea_parameter.Add(area);

            panel_area = eachArea_parameter.StartFromMinValue();
        }
    }
}
