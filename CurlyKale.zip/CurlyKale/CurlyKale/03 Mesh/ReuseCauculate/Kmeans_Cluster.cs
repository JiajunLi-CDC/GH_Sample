﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Grasshopper;
using Grasshopper.Kernel;
using Grasshopper.Kernel.Data;
using Grasshopper.Kernel.Types;
using CurlyKale.MachineLearning.Classes;

namespace CurlyKale._03_Mesh.ReuseCauculate
{
    class Kmeans_Cluster
    {
        // list of lists,用于学习的样本属性
        List<List<double>> inputList;
        int components ;  //分类的个数，应该大于1
        int seed;

        List<int> ClusterOutputs;
        List<double> ClusterLikelihood;
        List<List<double>> AttributeCentroid;

        public Kmeans_Cluster(List<List<double>> inputList, int components, int seed)
        {
            this.inputList = inputList;
            this.components = components;
            this.seed = seed;
        }

        public void Cauculate()
        {
            //Result
            clsML learning = new clsML();
            Tuple<int[], double[], double[][]> result = learning.KMeansClustering(inputList, components, seed);
            List<List<double>> resultList3 = result.Item3
                .Where(inner => inner != null) // Cope with uninitialised inner arrays.
                .Select(inner => inner.ToList()) // Project each inner array to a List<string>
                .ToList();

        
            ClusterOutputs = new List<int>();
            ClusterLikelihood = new List<double>();
            AttributeCentroid = new List<List<double>>();

            ClusterOutputs = result.Item1.ToList();
            ClusterLikelihood = result.Item2.ToList();
            AttributeCentroid = resultList3;

        }

        public List<int> getClusterResult()
        {
            return ClusterOutputs;
        }

        public List<double> getClusterrLikelihood()
        {
            return ClusterLikelihood;
        }

        public List<List<double>> getAttributeCentroid()
        {
            return AttributeCentroid;       
        }

    }
}
