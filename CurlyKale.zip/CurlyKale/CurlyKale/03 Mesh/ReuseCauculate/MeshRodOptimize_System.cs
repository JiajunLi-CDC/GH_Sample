﻿using Plankton;
using PlanktonGh;
using Rhino.Geometry;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hsy.GyresMesh;
using Hsy.Geo;
using Hsy.GyresMeshGH;

namespace CurlyKale._03_Mesh.ReuseCauculate
{
    public class MeshRodOptimize_System
    {
        public GE_Mesh mesh;

        public List<Rod> all_Rods = new List<Rod>();  //所有杆件
        public List<Panel> all_Panels = new List<Panel>();  //所有面板


        List<HS_Vector> totalMoves = new List<HS_Vector>();  //顶点的移动向量
        List<double> totalWeights;        //权重
        public int rodWeight;
        public int rodAngleWeight;
        public int panelWeight;
        public int faceAngleWeight;

        List<int> Rod_type_int = new List<int>();  //杆件分类情况
        List<int> Panel_type_int = new List<int>();  //面板分类情况       
        //List<double> likelihood = new List<double>();

        public int Rod_cluster_num;  //杆件分类的个数，应该大于1
        public int Panel_cluster_num;  //面板分类的个数，应该大于1
        int seed;

        public double tolerance;
        public double maxDifference;
        public double minRodAngle = double.MaxValue;
        double minRodAngleCountral;
        public double minFaceAngle = double.MaxValue;
        double minFaceAngleCountral = 0.33 * Math.PI;

        public bool state = false;

        List<List<Rod>> Rod_Type;  //杆件按着分类的分组排序
        List<List<Panel>> Panel_Type;  //面板按着分类的分组排序
        List<double> Final_Type_lenth;  //最终每种杆件的长度

        public List<double> Debug;
        public MeshRodOptimize_System(Mesh startingMesh, int Rod_cluster_num, double tolerance, double minRodAngleCountral, int lengthWeight, int rodAngleWeight)
        {
            mesh = startingMesh.ToGyresMesh();
            this.Rod_cluster_num = Rod_cluster_num;
            this.seed = 5;
            this.tolerance = tolerance;
            this.minRodAngleCountral = minRodAngleCountral;
            this.rodWeight = lengthWeight;
            this.rodAngleWeight = rodAngleWeight;
            initialize();
        }

        public MeshRodOptimize_System(Mesh startingMesh, int Rod_cluster_num, int Panel_cluster_num, double tolerance, double minRodAngleCountral, double minFaceAngleCountral, int rodLengthWeight, int iPanelWeight, int rodAngleWeight, int faceAngleWeight )
        {
            mesh = startingMesh.ToGyresMesh();
            this.Rod_cluster_num = Rod_cluster_num;
            this.Panel_cluster_num = Panel_cluster_num;
            this.seed = 5;
            this.tolerance = tolerance;
            this.minRodAngleCountral = minRodAngleCountral;
            this.minFaceAngleCountral = minFaceAngleCountral;
            this.rodWeight = rodLengthWeight;
            this.rodAngleWeight = rodAngleWeight;
            this.panelWeight = iPanelWeight;
            this.faceAngleWeight = faceAngleWeight;
            initialize2();
        }

        public Mesh GetRhinoMesh()
        {
            return mesh.ToRhinoMesh();
        }

        void initialize()
        {
            for (int i = 0; i < mesh.GetEdges().Count; i++)
            {
                GE_Halfedge edge = mesh.GetEdges()[i];
                Rod rod = new Rod(i, edge);
                all_Rods.Add(rod);
            }

            getExpected_Length_ByEdge(Rod_cluster_num, seed);  //根据现有长度的分组区间情况获取每根杆件的期望长度
        }

        void initialize2()
        {
            for (int i = 0; i < mesh.GetEdges().Count; i++)
            {
                GE_Halfedge edge = mesh.GetEdges()[i];
                Rod rod = new Rod(i, edge);
                all_Rods.Add(rod);
            }

            for (int i = 0; i < mesh.GetFaces().Count; i++)
            {
                GE_Face face = mesh.GetFaces()[i];

                List<Rod> panelRods = new List<Rod>();
                for (int j = 0; j < face.GetFaceHalfedges().Count; j++)
                {
                    GE_Halfedge he = face.GetFaceHalfedges()[j];
                    GE_Halfedge he_pair = he.Pair();

                    int index1 = mesh.GetIndex(he);
                    int index2 = mesh.GetIndex(he_pair);
                    if (index1 == -1 || index2 != -1)  //判断face中的edge所在半边对应edges中的序号
                    {
                        panelRods.Add(all_Rods[index2]);
                    }
                    else
                    {
                        panelRods.Add(all_Rods[index1]);
                    }

                }

                Panel panel = new Panel(i, face, panelRods);
                all_Panels.Add(panel);
            }


            getExpected_Length_ByEdge(Rod_cluster_num, seed);  //根据现有杆件长度的分组区间情况获取每根杆件的期望长度
            getExpected_Length_ByFace(Panel_cluster_num, seed);  //根据现有面板的分组区间情况获取面板的边长期望长度
        }

        public List<double> GetExpected_Length()
        {
            List<double> exp_length = new List<double>();
            for (int i = 0; i < mesh.GetEdges().Count; i++)
            {
                exp_length.Add(all_Rods[i].expect_length_ByEdge);
            }
            return exp_length;
        }

        public List<int> GetRodType()
        {
            return Rod_type_int;
        }

        public List<double> GetFinal_Type_lenth()
        {
            return Final_Type_lenth;
        }

        public List<int> GetPanelType()
        {
            return Panel_type_int;
        }

        public void getExpected_Length_ByEdge(int cluster_num, int seed)
        {
            List<List<double>> inputList = new List<List<double>>();  //杆件属性的记录树形结构          

            //记录属性
            for (int i = 0; i < all_Rods.Count; i++)
            {
                List<double> each_attribute = new List<double>(0);  //每个杆件的属性记录

                each_attribute.Add(all_Rods[i].getlength());  //第一个属性记录为长度

                inputList.Add(each_attribute);
            }

            List<int> results = new List<int>();
            bool cluster_done = false;
            while (cluster_done == false)
            {
                Kmeans_Cluster kmeans = new Kmeans_Cluster(inputList, cluster_num, seed);   //属性，分类数量，seed
                kmeans.Cauculate();
                results = kmeans.getClusterResult();
                List<List<double>> AttributeCentroid = kmeans.getAttributeCentroid();
                //List<double> averageLen_all_type = new List<double>();  //每个聚类的长度平均值

                Rod_Type = new List<List<Rod>>();  //记录不同类型杆件分组情况

                for (int i = 0; i < cluster_num; i++)   //根据k-means分类结果重新设置杆件目标长度
                {
                    List<Rod> a_Type_Rods = new List<Rod>();  //新建一种类型的杆件的list集合
                    for (int j = 0; j < results.Count; j++)
                    {
                        if (results[j] == i)
                        {
                            all_Rods[j].expect_length_ByEdge = AttributeCentroid[i][0];  //每个聚类的长度平均值
                            a_Type_Rods.Add(all_Rods[j]);
                        }
                    }

                    if (a_Type_Rods.Count == 0)  //如果出现有一种聚类没有杆件
                    {
                        cluster_done = false;
                        this.Rod_cluster_num -= 1;
                        cluster_num -= 1;
                        break;
                    }
                    else
                    {
                        cluster_done = true;
                        Rod_Type.Add(a_Type_Rods);

                        //averageLen_all_type.Add(AttributeCentroid[i][0]);
                    }

                    //double min=GetRod_type_difference(averageLen_all_type);
                    //if (min < tolerance)    //如果杆件聚类的平均最小差距小于阈值t1,则说明有两个聚类过于相似，聚类种数减少1并重新聚类
                    //{
                    //    cluster_done = false;
                    //    this.Rod_cluster_num -= 1;
                    //    cluster_num -= 1;                 
                    //}
                }
            }

            Rod_type_int.Clear();
            Rod_type_int = results;
        }

        public void getExpected_Length_ByFace(int cluster_num, int seed)
        {
            //int n = this.Rod_cluster_num;
            //int nm = 2 * (n * (n - 1) * (n - 2) / (3 * 2 * 1));   //cn3排列算法:  An3 = n(n - 1)(n - 2) / (3×2×1)，加上对称
            //if (nm < this.Panel_cluster_num)
            //{
            //    this.Panel_cluster_num = nm;
            //    cluster_num = nm;
            //}

            List<Panel> PanelList = all_Panels;

            List<List<double>> inputList = PanelList.GetPanels_parameter();  //获取聚类属性,其中每个panel的属性排序已经重置
            List<int> results = new List<int>();

            bool cluster_done = false;
            while (cluster_done == false)
            {
                Kmeans_Cluster kmeans = new Kmeans_Cluster(inputList, cluster_num, seed);   //属性，分类数量，seed
                kmeans.Cauculate();
                results.Clear();
                results = kmeans.getClusterResult();

                Panel_Type = new List<List<Panel>>();  //记录不同类型面板分组情况

                for (int i = 0; i < cluster_num; i++)   //根据k-means分类结果重新设置杆件目标长度
                {
                    List<Panel> a_Type_Panels = new List<Panel>();  //新建一种类型的面板的list集合
                    for (int j = 0; j < results.Count; j++)
                    {
                        if (results[j] == i)
                        {
                            a_Type_Panels.Add(PanelList[j]);
                        }
                    }

                    if (a_Type_Panels.Count == 0)  //如果出现有一种聚类没有面板
                    {
                        cluster_done = false;
                        this.Panel_cluster_num -= 1;
                        cluster_num -= 1;
                        break;
                    }
                    else
                    {
                        cluster_done = true;
                        Panel_Type.Add(a_Type_Panels);
                    }
                }
            }

            Debug = new List<double>();
            for (int i = 0; i < Panel_Type.Count; i++)   //计算每个面板的相似面板个数
            {
                List<Panel> a_Type_Panels = Panel_Type[i];
                if (a_Type_Panels.Count == 1)
                {
                    a_Type_Panels[0].similarPanel_Count = 0;    //一个面板和他相似的面板个数
                    Debug.Add(a_Type_Panels[0].similarPanel_Count);
                }
                else
                {
                    for (int j = 0; j < a_Type_Panels.Count; j++)
                    {
                        a_Type_Panels[j].similarPanel_Count = a_Type_Panels.Count - 1;
                        Debug.Add(a_Type_Panels[j].similarPanel_Count);
                    }
                }
            }

            for (int i = 0; i < Panel_Type.Count; i++)   //每一个面板聚类,计算每个面板的三边相似平均值
            {
                List<Panel> a_Type_Panels = Panel_Type[i];

                List<double> panel_expect_lenths = new List<double>();  //新建一个面板的边期望值（平均值）记录
                for (int j = 0; j < a_Type_Panels[0].panel_Lengths.Count; j++)  //一种类型的面板的所有边，默认一种聚类所有面边长个数相同
                {
                    List<double> each_edge_average = new List<double>();

                    for (int k = 0; k < a_Type_Panels.Count; k++)  //一种类型的面板的list个数
                    {
                        each_edge_average.Add(a_Type_Panels[k].panel_Lengths[j]);
                    }
                    double averageLen = each_edge_average.Average();  //计算出每个聚类面板的每条边平均长度，按照从最小的排序开始（同panel类中的记录）

                    panel_expect_lenths.Add(averageLen);
                }

                for (int m = 0; m < a_Type_Panels.Count; m++)  //一种类型的面板的average值赋予
                {
                    a_Type_Panels[m].expected_length.Clear();
                    a_Type_Panels[m].expected_length = panel_expect_lenths;
                }

            }

            Panel_type_int.Clear();
            Panel_type_int = results;
        }

        public void getExpected_Length_ByFace_notUsingMatchingLearning()
        {
            List<Panel> PanelList = all_Panels;
            List<List<double>> inputList = PanelList.GetPanels_parameter();  //获取聚类属性,其中每个panel的属性排序已经重置

            for (int i = 0; i < Panel_Type.Count; i++)   //每一个面板聚类,计算每个面板的三边相似平均值
            {
                List<Panel> a_Type_Panels = Panel_Type[i];


                List<double> panel_expect_lenths = new List<double>();  //新建一个面板的边期望值（平均值）记录
                for (int j = 0; j < a_Type_Panels[0].panel_Lengths.Count; j++)  //一种类型的面板的所有边，默认一种聚类所有面边长个数相同
                {
                    List<double> each_edge_average = new List<double>();

                    for (int k = 0; k < a_Type_Panels.Count; k++)  //一种类型的面板的list个数
                    {
                        each_edge_average.Add(a_Type_Panels[k].panel_Lengths[j]);
                    }
                    double averageLen = each_edge_average.Average();  //计算出每个聚类面板的每条边平均长度，按照从最小的排序开始（同panel类中的记录）

                    panel_expect_lenths.Add(averageLen);
                }

                for (int m = 0; m < a_Type_Panels.Count; m++)  //一种类型的面板的average值赋予
                {
                    a_Type_Panels[m].expected_length.Clear();
                    a_Type_Panels[m].expected_length = panel_expect_lenths;
                }

            }
        }

        public void refreshData()
        {
            totalMoves = new List<HS_Vector>();
            totalWeights = new List<double>();

            for (int i = 0; i < mesh.GetVertices().Count; i++)
            {
                totalMoves.Add(new HS_Vector(0, 0, 0));
                totalWeights.Add(0.0);
            }
        }

        public bool CauculateRodState()
        {
            bool Done = true;
            maxDifference = double.MinValue;
            Final_Type_lenth = new List<double>();

            for (int i = 0; i < Rod_Type.Count; i++)   //每个杆件分组
            {
                double minLen = double.MaxValue;
                double maxLen = double.MinValue;

                for (int j = 0; j < Rod_Type[i].Count; j++)
                {
                    if (Rod_Type[i][j].getlength() < minLen)
                    {
                        minLen = Rod_Type[i][j].getlength();
                    }
                    if (Rod_Type[i][j].getlength() > maxLen)
                    {
                        maxLen = Rod_Type[i][j].getlength();
                    }
                }

                Final_Type_lenth.Add(minLen);  //每个聚类的杆件以最短的杆件为标准
                double difference = maxLen - minLen;
                if (difference > maxDifference)
                {
                    maxDifference = difference;
                }
            }

            if (maxDifference > tolerance || minRodAngle < minRodAngleCountral * 0.96 || minFaceAngle < minFaceAngleCountral * 0.96)   //判断杆件是否达到优化标注
            {
                Done = false;
            }
            return Done;
        }

        public double GetRod_type_difference(List<double> Final_Type_lenth)
        {
            double minTypeDifferent = double.MaxValue;  //每种聚类杆件之间的最小差距
            for (int i = 0; i < Final_Type_lenth.Count; i++)
            {
                double a = Final_Type_lenth[i];
                for (int j = i + 1; j < Final_Type_lenth.Count; j++)
                {
                    double b = Final_Type_lenth[j];
                    double dif = Math.Abs(a - b);
                    if (dif < minTypeDifferent)
                    {
                        minTypeDifferent = dif;
                    }
                }
            }
            return minTypeDifferent;
        }

        public void PanelOptimize()
        {
            for (int i = 0; i < all_Panels.Count; i++)
            {
                if (all_Panels[i].similarPanel_Count != 0)    //如果一种面板的聚类不只有它一种
                {
                    for (int j = 0; j < all_Panels[i].getRods().Count; j++)
                    {
                        Rod rod = all_Panels[i].getRods()[j];
                        int startIndex = mesh.GetIndex(rod.startVertex);
                        int endIndex = mesh.GetIndex(rod.endVertex);

                        double expect_len = all_Panels[i].expected_length[j];
                        HS_Vector move = rod.getLengthConstraint_MoveVector(expect_len);

                        totalMoves[startIndex].Set(HS_Vector.add(totalMoves[startIndex], HS_Vector.mul(move, 2 * panelWeight)));
                        totalMoves[endIndex].Set(HS_Vector.sub(totalMoves[endIndex], HS_Vector.mul(move, 2 * panelWeight)));

                        totalWeights[startIndex] += 2 * panelWeight;
                        totalWeights[endIndex] += 2 * panelWeight;
                    }
                }
            }

        }

        public void RodOptimize()
        {
            for (int i = 0; i < all_Rods.Count(); i++)
            {
                Rod rod = all_Rods[i];
                int startIndex = mesh.GetIndex(rod.startVertex);
                int endIndex = mesh.GetIndex(rod.endVertex);

                HS_Vector move = rod.getLengthConstraint_MoveVector(rod.expect_length_ByEdge);

                totalMoves[startIndex].Set(HS_Vector.add(totalMoves[startIndex], HS_Vector.mul(move, 2 * rodWeight)));
                totalMoves[endIndex].Set(HS_Vector.sub(totalMoves[endIndex], HS_Vector.mul(move, 2 * rodWeight)));

                totalWeights[startIndex] += 2 * rodWeight;
                totalWeights[endIndex] += 2 * rodWeight;
            }
        }

        public void RodAngleOptimize()
        {
            minRodAngle = double.MaxValue;


            for (int i = 0; i < mesh.GetVertices().Count; i++)  //对于每个顶点的节点，任意两条相连的杆件之间夹角不应小于30°
            {
                for (int j = 0; j < mesh.GetVertices()[i].GetHalfedgeStar().Count; j++)
                {
                    for (int k = j + 1; k < mesh.GetVertices()[i].GetHalfedgeStar().Count; k++)
                    {

                        GE_Halfedge edge1 = mesh.GetVertices()[i].GetHalfedgeStar()[j];
                        GE_Halfedge edge2 = mesh.GetVertices()[i].GetHalfedgeStar()[k];

                        Point3d position = new Point3d(edge1.GetStartPosition().xd, edge1.GetStartPosition().yd, edge1.GetStartPosition().zd);
                        Point3d position2 = new Point3d(edge1.GetEndPosition().xd, edge1.GetEndPosition().yd, edge1.GetEndPosition().zd);
                        Point3d position3 = new Point3d(edge2.GetStartPosition().xd, edge2.GetStartPosition().yd, edge2.GetStartPosition().zd);
                        Point3d position4 = new Point3d(edge2.GetEndPosition().xd, edge2.GetEndPosition().yd, edge2.GetEndPosition().zd);

                        Vector3d vectorAB = position2 - position;
                        Vector3d vectorAC = position4 - position3;

                        double angle = Vector3d.VectorAngle(vectorAB, vectorAC);
                        if (angle < minRodAngle)
                        {
                            minRodAngle = angle;
                        }
                        if (angle <= minRodAngleCountral && rodAngleWeight != 0) 
                        {
                            ////方法一
                            //double num = 2.0 * Math.Sin(Vector3d.VectorAngle(vectorAB, vectorAC) - minAngleCountral);
                            //double length = (vectorAB + vectorAC).Length;
                            //double num2 = num / (vectorAB.Length * length);
                            //double num3 = num / (vectorAC.Length * length);
                            //Vector3d vector3d3 = Vector3d.CrossProduct(vectorAB, vectorAC);
                            //Vector3d vector3d4 = Vector3d.CrossProduct(vectorAB, vector3d3);
                            //Vector3d vector3d5 = Vector3d.CrossProduct(vector3d3, vectorAC);
                            //vector3d4.Unitize();
                            //vector3d5.Unitize();
                            ////vector3d4 *= num2;
                            ////vector3d5 *= num3;
                            //vector3d4 *= num2 * 10000;
                            //vector3d5 *= num3 * 10000;

                            //HS_Vector move1 = new HS_Vector(vector3d4.X, vector3d4.Y, vector3d4.Z);
                            //HS_Vector move2 = new HS_Vector(vector3d5.X, vector3d5.Y, vector3d5.Z);

                            //GE_Vertex v1 = edge1.GetStart();
                            //GE_Vertex v2 = edge1.GetEnd();
                            //GE_Vertex v3 = edge2.GetStart();
                            //GE_Vertex v4 = edge2.GetEnd();

                            //int index1 = mesh.GetIndex(v1);
                            //int index2 = mesh.GetIndex(v2);
                            //int index3 = mesh.GetIndex(v3);
                            //int index4 = mesh.GetIndex(v4);

                            //totalMoves[index1].Set(HS_Vector.add(totalMoves[index1], HS_Vector.mul(move1, angleWeight)));
                            //totalMoves[index2].Set(HS_Vector.sub(totalMoves[index2], HS_Vector.mul(move1, angleWeight)));
                            //totalMoves[index3].Set(HS_Vector.add(totalMoves[index3], HS_Vector.mul(move2, angleWeight)));
                            //totalMoves[index4].Set(HS_Vector.sub(totalMoves[index4], HS_Vector.mul(move2, angleWeight)));
                            //totalWeights[index1] += angleWeight;
                            //totalWeights[index2] += angleWeight;
                            //totalWeights[index3] += angleWeight;
                            //totalWeights[index4] += angleWeight;

                            //方法二
                            double num = 2.0 * Math.Sin(Vector3d.VectorAngle(vectorAB, vectorAC) - minRodAngleCountral);
                            double length = (vectorAB + vectorAC).Length;
                            double num2 = vectorAB.Length * num / length;
                            double num3 = vectorAC.Length * num / length;
                            Vector3d vector3d3 = Vector3d.CrossProduct(vectorAB, vectorAC);
                            vector3d3.Unitize();
                            Vector3d vector3d4 = Vector3d.CrossProduct(vectorAB, vector3d3);
                            Vector3d vector3d5 = Vector3d.CrossProduct(vector3d3, vectorAC);
                            vector3d4 *= 0.25 * num2;
                            vector3d5 *= 0.25 * num3;

                            HS_Vector move1 = new HS_Vector(vector3d4.X, vector3d4.Y, vector3d4.Z);
                            HS_Vector move2 = new HS_Vector(vector3d5.X, vector3d5.Y, vector3d5.Z);

                            GE_Vertex v1 = edge1.GetStart();
                            GE_Vertex v2 = edge1.GetEnd();
                            GE_Vertex v3 = edge2.GetStart();
                            GE_Vertex v4 = edge2.GetEnd();

                            int index1 = mesh.GetIndex(v1);
                            int index2 = mesh.GetIndex(v2);
                            int index3 = mesh.GetIndex(v3);
                            int index4 = mesh.GetIndex(v4);

                            //double weight1 = 4.0 * angleWeight / (vectorAB.Length * vectorAB.Length * vectorAB.Length);
                            //double weight2 = 4.0 * angleWeight / (vectorAC.Length * vectorAC.Length * vectorAC.Length);

                            double n1 = (vectorAB.Length * vectorAB.Length * vectorAB.Length) / (vectorAC.Length * vectorAC.Length * vectorAC.Length);

                            double weight1 = rodAngleWeight;
                            double weight2 = weight1 * n1;

                            totalMoves[index1].Set(HS_Vector.add(totalMoves[index1], HS_Vector.mul(move1, weight1)));
                            totalMoves[index2].Set(HS_Vector.sub(totalMoves[index2], HS_Vector.mul(move1, weight1)));
                            totalMoves[index3].Set(HS_Vector.add(totalMoves[index3], HS_Vector.mul(move2, weight2)));
                            totalMoves[index4].Set(HS_Vector.sub(totalMoves[index4], HS_Vector.mul(move2, weight2)));
                            totalWeights[index1] += weight1;
                            totalWeights[index2] += weight1;
                            totalWeights[index3] += weight2;
                            totalWeights[index4] += weight2;
                        }
                    }
                }
            }
        }

        public void FaceAngleOptimize()
        {
            minFaceAngle = double.MaxValue;

            for (int i = 0; i < all_Rods.Count; i++)
            {
                GE_Halfedge he = all_Rods[i].getHalfedge();

                if (!he.IsOuterBoundary() && !he.IsInnerBoundary())
                {    //不是边缘三角面

                    Point3d position = new Point3d(he.GetStart().xd, he.GetStart().yd, he.GetStart().zd);  //两个折叠边的点,注意按照逆时针方向记录
                    Point3d position2 = new Point3d(he.GetEnd().xd, he.GetEnd().yd, he.GetEnd().zd);

                    HS_Point pointA = he.GetPrevInFace().GetStart().GetPosition();   //两个折叠点
                    HS_Point pointB = he.Pair().GetPrevInFace().GetStart().GetPosition();
                    Point3d position3 = new Point3d(pointA.xd, pointA.yd, pointA.zd);
                    Point3d position4 = new Point3d(pointB.xd, pointB.yd, pointB.zd);

                    Vector3d vector3d = position2 - position;
                    Vector3d vector3d2 = position3 - position;
                    Vector3d vector3d3 = position4 - position;
                    Vector3d vector3d4 = position2 - position3;
                    Vector3d vector3d5 = position2 - position4;

                    double length = vector3d.Length;    //折叠边的长度
                    double num = 1.0 / length;
                    double length2 = (vector3d2 - vector3d2 * num * num * vector3d * vector3d).Length;
                    double length3 = (vector3d3 - vector3d3 * num * num * vector3d * vector3d).Length;
                    double num2 = 0.5 / (length2 + length3);
                    double num3 = vector3d2 * vector3d;
                    double num4 = vector3d3 * vector3d;
                    double num5 = vector3d4 * vector3d;
                    double num6 = vector3d5 * vector3d;
                    Vector3d vector3d6 = Vector3d.CrossProduct(vector3d2, vector3d);
                    Vector3d vector3d7 = Vector3d.CrossProduct(vector3d, vector3d3);
                    double num7 = Vector3d.VectorAngle(vector3d6, vector3d7, new Plane(position, vector3d));

                    double FaceAngle = Math.PI - num7;                //要判断此时的Angle的正负值

                    if (FaceAngle > 0 && FaceAngle < minFaceAngle)    //找出最小角度
                    {
                        minFaceAngle = FaceAngle;
                    }
                    else if (Math.Abs(FaceAngle) < minFaceAngle)
                    {
                        minFaceAngle = Math.Abs(FaceAngle);
                    }


                    if (FaceAngle < minFaceAngleCountral && Math.Abs(FaceAngle) < minFaceAngleCountral && faceAngleWeight != 0) 
                    {
                        double restAngle = 0;
                        if (FaceAngle > 0)   //两个面夹角在180°之间
                        {
                            restAngle = Math.PI - minFaceAngleCountral;
                        }
                        else    //两个面夹角大于180°
                        {
                            restAngle = -(Math.PI - minFaceAngleCountral);
                        }

                        double num777 = num7;
                        if (num777 > 3.1415926535897931)
                        {
                            num777 -= 6.2831853071795862;
                        }

                        //四个顶点移动向量的计算
                        double num8 = num777 - restAngle;
                        double num9 = 1.0 / vector3d6.Length;
                        double num10 = num3 * num9;
                        double num11 = num5 * num9;
                        num9 = 1.0 / vector3d7.Length;
                        double num12 = num4 * num9;
                        double num13 = num6 * num9;
                        double num14 = num8 * num2 * 0.5;
                        Vector3d vector3d8 = vector3d6 * num14;

                        Vector3d Move0 = num11 * vector3d8;
                        Vector3d Move1 = num10 * vector3d8;
                        Vector3d Move2 = -(num11 + num10) * vector3d8;

                        HS_Vector move0 = new HS_Vector(Move0.X, Move0.Y, Move0.Z);
                        HS_Vector move1 = new HS_Vector(Move1.X, Move1.Y, Move1.Z);
                        HS_Vector move2 = new HS_Vector(Move2.X, Move2.Y, Move2.Z);

                        vector3d8 = vector3d7 * num14;
                        HS_Vector vec3d8 = new HS_Vector(vector3d8.X, vector3d8.Y, vector3d8.Z);

                        move0 += num13 * vec3d8;
                        move1 += num12 * vec3d8;
                        HS_Vector move3 = -(num13 + num12) * vec3d8;

                        GE_Vertex v1 = he.GetStart();
                        GE_Vertex v2 = he.GetEnd();
                        GE_Vertex v3 = he.GetPrevInFace().GetStart();
                        GE_Vertex v4 = he.Pair().GetPrevInFace().GetStart();

                        int index1 = mesh.GetIndex(v1);
                        int index2 = mesh.GetIndex(v2);
                        int index3 = mesh.GetIndex(v3);
                        int index4 = mesh.GetIndex(v4);

                        double weight1 = faceAngleWeight;

                        totalMoves[index1].Set(HS_Vector.add(totalMoves[index1], HS_Vector.mul(move0, weight1)));
                        totalMoves[index2].Set(HS_Vector.add(totalMoves[index2], HS_Vector.mul(move1, weight1)));
                        totalMoves[index3].Set(HS_Vector.add(totalMoves[index3], HS_Vector.mul(move2, weight1)));
                        totalMoves[index4].Set(HS_Vector.add(totalMoves[index4], HS_Vector.mul(move3, weight1)));
                        totalWeights[index1] += weight1;
                        totalWeights[index2] += weight1;
                        totalWeights[index3] += weight1;
                        totalWeights[index4] += weight1;
                    }
                }
            }
        }

        public void UpdateVertexPosition()
        {
            for (int i = 0; i < mesh.GetVertices().Count; i++)
            {

                if (mesh.GetVertices()[i].isBoundary())
                {   //控制边界的点的移动

                    //continue;

                    if (totalWeights[i] == 0.0) continue;
                    HS_Vector move = totalMoves[i].div(totalWeights[i]);    //每次更新需要移动的向量大小
                    HS_Vector move_new = new HS_Vector(move.xf, move.yf, 0);
                    HS_Point newPosition = mesh.getPositionWithIndex(i).add(move_new);

                    GE_Vertex v = mesh.getVertexWithIndex(i);   //更新最终的点位置
                    v.Set(newPosition);

                }
                else
                {
                    if (totalWeights[i] == 0.0) continue;
                    HS_Vector move = totalMoves[i].div(totalWeights[i]);    //每次更新需要移动的向量大小

                    HS_Point newPosition = mesh.getPositionWithIndex(i).add(move);

                    GE_Vertex v = mesh.getVertexWithIndex(i);   //更新最终的点位置                  
                    v.Set(newPosition);
                }

            }
        }
    }

}
