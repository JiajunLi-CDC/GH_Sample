﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurlyKale._03_Mesh.ReuseCauculate
{
    public static class DataFactory
    {
        public static List<List<double>> StartFromMinValue(this List<List<double>> InputList)
        {
            List<List<double>> OutputList = new List<List<double>>();

            double minValue;

            for (int i = 0; i < InputList.Count; i++)
            {
                minValue = InputList[i].Min();

                for (int j = 0; j < InputList[i].Count; j++)
                {
                    if (InputList[i][j] == minValue)
                    {
                        List<double> L1 = InputList[i].Skip(j).ToList();
                        List<double> L2 = InputList[i].Take(j).ToList();

                        L1.AddRange(L2);
                        OutputList.Add(L1);
                        break;
                    }
                }
            }
            return OutputList;
        }

        public static List<double> StartFromMinValue(this List<double> InputList)
        {
            List<double> OutputList = new List<double>();

            double minValue;
            minValue = InputList.Min();

            for (int i = 0; i < InputList.Count; i++)
            {
                if (InputList[i] == minValue)
                {
                    List<double> L1 = InputList.Skip(i).ToList();
                    List<double> L2 = InputList.Take(i).ToList();

                    L1.AddRange(L2);
                    OutputList = L1;
                    break;
                }
            }

            return OutputList;
        }

        public static List<List<double>> NormalizeList(this List<List<double>> InputList)
        {
            List<List<double>> OutputList = new List<List<double>>();
            List<double> AllData = new List<double>();

            for (int i = 0; i < InputList.Count; i++)
            {
                for (int j = 0; j < InputList[i].Count; j++)
                {
                    AllData.Add(InputList[i][j]);
                }
            }

            double n_min = AllData.Min();
            double n_max = AllData.Max();
            for (int i = 0; i < InputList.Count; i++)
            {
                List<double> subList = new List<double>();

                if (n_max != n_min)
                {
                    for (int j = 0; j < InputList[i].Count; j++)
                    {
                        double n = (InputList[i][j] - n_min) / (n_max - n_min);
                        subList.Add(n);
                    }
                }
                else
                {
                    subList.Add(1d);
                }

                OutputList.Add(subList);
            }

            return OutputList;
        }

    }
}
