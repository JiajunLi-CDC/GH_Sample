﻿using CurlyKale._03_Mesh.ReuseCauculate;
using Rhino.Geometry;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hsy.GyresMesh;
using Hsy.Geo;

namespace CurlyKale._03_Mesh
{
    public static class MeshFactory
    {
        public static List<Line> GetAllRodLines(this MeshRodOptimize_System myRodOptimize_System)
        {
            List<Line> lines = new List<Line>();

            for (int i = 0; i < myRodOptimize_System.all_Rods.Count(); i++)
            {
                Rod rod = myRodOptimize_System.all_Rods[i];
                Point3d A = new Point3d(rod.startVertex.xd, rod.startVertex.yd, rod.startVertex.zd);
                Point3d B = new Point3d(rod.endVertex.xd, rod.endVertex.yd, rod.endVertex.zd);

                Line line = new Line(A, B);
                lines.Add(line);
            }
            return lines;
        }

        public static List<List<double>> GetFaces_parameter(this GE_Mesh mesh)
        {
            //List<List<GE_Face>> faces_cluster = new List<List<GE_Face>>();

            //GE_Mesh mesh = myRodOptimize_System.mesh;
            List<GE_Face> AllFaces = mesh.GetFaces();

            List<List<double>> faces_parameters = new List<List<double>>();       //记录faces的属性,边长、角度、面积 

            List<List<double>> faces_len = new List<List<double>>();    //记录长度的数据
            List<List<double>> faces_angle = new List<List<double>>();    //记录角度的数据
            List<List<double>> faces_area = new List<List<double>>();    //记录角度的数据


            for (int i = 0; i < AllFaces.Count; i++)  //记录边长
            {
                List<double> eachLen_parameter = new List<double>();

                for (int j = 0; j < AllFaces[i].GetFaceHalfedges().Count; j++)
                {
                    GE_Halfedge edge = AllFaces[i].GetFaceHalfedges()[j];
                    double n = edge.GetLength();
                    eachLen_parameter.Add(n);
                }
                faces_len.Add(eachLen_parameter);
            }
            faces_len = faces_len.StartFromMinValue();


            for (int i = 0; i < AllFaces.Count; i++)  //记录角度
            {
                List<double> eachAngle_parameter = new List<double>();
                for (int j = 0; j < AllFaces[i].GetFaceHalfedges().Count; j++)
                {
                    GE_Halfedge edge1 = AllFaces[i].GetFaceHalfedges()[j];
                    GE_Halfedge edge2;
                    if (j == AllFaces[i].GetFaceHalfedges().Count - 1)
                    {
                        edge2 = AllFaces[i].GetFaceHalfedges()[0];
                    }
                    else
                    {
                        edge2 = AllFaces[i].GetFaceHalfedges()[j + 1];
                    }

                    HS_Vector n1 = edge1.GetStartPosition();
                    HS_Vector n2 = edge1.GetEndPosition();
                    HS_Vector n3 = edge2.GetStartPosition();
                    HS_Vector n4 = edge2.GetEndPosition();

                    HS_Vector v1 = HS_Vector.sub(n1, n2);
                    HS_Vector v2 = HS_Vector.sub(n4, n3);

                    double angle = HS_Vector.angle(v1, v2);
                    eachAngle_parameter.Add(angle);
                }
                faces_angle.Add(eachAngle_parameter);
            }
            faces_angle = faces_angle.StartFromMinValue();


            for (int i = 0; i < AllFaces.Count; i++)  //记录面积，这里暂时以三角形的海伦公式代替，只能适用三角形网格
            {
                List<double> eachArea_parameter = new List<double>();
                GE_Face face = AllFaces[i];
                double area = 0;

                if (face.GetFaceVertices().Count == 3)
                {
                    //Halen method for triangle
                    double n1 = faces_len[i][0];
                    double n2 = faces_len[i][1];
                    double n3 = faces_len[i][2];
                    double s = 0.5 * (n1 + n2 + n3);
                    area = Math.Sqrt(s * (s - n1) * (s - n2) * (s - n3));
                }
                else
                {
                    List<HS_Coord> points = new List<HS_Coord>();
                    for (int j = 0; j < face.GetFaceVertices().Count; j++)
                    {
                        points.Add(face.GetFaceVertices()[j]);
                    }
                    HS_Polygon poly = new HS_Polygon(points);
                    area = Math.Abs(poly.GetSignedArea());
                }

                eachArea_parameter.Add(area);
                faces_area.Add(eachArea_parameter);
            }

            faces_len = faces_len.NormalizeList();
            faces_angle = faces_angle.NormalizeList();
            faces_area = faces_area.NormalizeList();

            for (int i = 0; i < AllFaces.Count; i++)  //记录faces的所有归一化的属性
            {
                faces_len[i].AddRange(faces_angle[i]);
                faces_len[i].AddRange(faces_area[i]);

                faces_parameters.Add(faces_len[i]);
            }
            return faces_parameters;
        }

        public static List<List<double>> GetPanels_parameter(this List<Panel> panels)
        {                 

            List<List<double>> panels_parameters = new List<List<double>>();       //记录faces的属性,边长、角度、面积 

            List<List<double>> faces_len = new List<List<double>>();    //记录长度的数据
            List<List<double>> faces_angle = new List<List<double>>();    //记录角度的数据
            List<List<double>> faces_area = new List<List<double>>();    //记录角度的数据

            for (int i = 0; i < panels.Count; i++)
            {
                panels[i].RefreshParameters();
                faces_len.Add(panels[i].panel_Lengths);
                faces_angle.Add(panels[i].panel_angles);
                faces_area.Add(panels[i].panel_area);
            }

            faces_len = faces_len.NormalizeList();
            faces_angle = faces_angle.NormalizeList();
            faces_area = faces_area.NormalizeList();

            for (int i = 0; i < panels.Count; i++)  //记录faces的所有归一化的属性
            {
                faces_len[i].AddRange(faces_angle[i]);
                faces_len[i].AddRange(faces_area[i]);

                panels_parameters.Add(faces_len[i]);
            }
            return panels_parameters;
        }
        public static double Getangle(double a, double b, double c)
        {
            double angle = Math.Acos((a * a + b * b - c * c) / (2 * a * b));
            return angle;
        }

    }
}
