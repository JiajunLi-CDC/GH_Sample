﻿using Grasshopper.Kernel;
using Hsy.GyresMesh;
using Rhino.Geometry;
using System;
using System.Collections.Generic;
using Hsy.GyresMeshGH;

namespace CurlyKale._03_Mesh.MeshGrowth
{
    public class GhcToGyresMesh : GH_Component
    {
        #region Register Node
        public GhcToGyresMesh()
        : base("ToGyresMesh", "GeMesh", "将RhinoMesh转化为GeMesh", "CurlyKale", "03 MeshGrowth")
        {
        }

        protected override System.Drawing.Bitmap Icon
        {
            get
            {

                return Properties.Resources.ToGyresMesh;
            }
        }

        public override GH_Exposure Exposure
        {
            get
            {
                return GH_Exposure.secondary;
            }
        }

        public override Guid ComponentGuid
        {
            get
            {
                return new Guid("91a4fcc1-53bc-4acd-a0f4-7611f44b9abc");
            }
        }
        #endregion


        #region Inputs/Outputs
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddMeshParameter("RhinoMesh", "RhMesh", "初始Rhino网格", GH_ParamAccess.item);
        }


        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.Register_GenericParam("GyresMesh", "GeMesh", "Gyres网格", GH_ParamAccess.item);
        }
        #endregion


        #region Solution
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            Mesh iRhinoMesh = null;

            DA.GetData("RhinoMesh", ref iRhinoMesh);

            if (iRhinoMesh == null)
            {
                AddRuntimeMessage(GH_RuntimeMessageLevel.Warning, "Failed to collect any valid RhinoMesh.");
            }

            //=============================================================================================

            GE_Mesh geMesh = new GE_Mesh();
            if (iRhinoMesh != null)
            {             
                geMesh = iRhinoMesh.ToGyresMesh();
            }


            DA.SetData("GyresMesh", geMesh);
        }
        #endregion


    }
}