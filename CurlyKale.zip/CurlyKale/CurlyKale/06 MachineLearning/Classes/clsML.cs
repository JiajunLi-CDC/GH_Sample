﻿using System;
using System.Collections.Generic;
using System.Linq;

using Accord.Math;
using Accord.Neuro;
using Accord.Neuro.Learning;
using Accord.Statistics.Kernels;
using Accord.Statistics.Filters;
using Accord.Statistics.Models.Regression;
using Accord.Statistics.Models.Regression.Linear;
using Accord.Statistics.Models.Regression.Fitting;
using Accord.MachineLearning.Bayes;
using Accord.MachineLearning.VectorMachines;
using Accord.MachineLearning.VectorMachines.Learning;
using Accord.Math.Optimization.Losses;
using System.Data;
using Accord.MachineLearning;
using Accord.Statistics.Models.Markov;
using Accord.Statistics.Models.Markov.Learning;
using Accord.Statistics.Models.Markov.Topology;
using Accord.Statistics.Distributions.Multivariate;
using Accord.Neuro.ActivationFunctions;
using Accord.Neuro.Networks;
using Accord.Statistics.Distributions.Fitting;
using Accord.Statistics.Distributions.Univariate;
using Accord.MachineLearning.Performance;
using Accord.Statistics.Visualizations;

namespace CurlyKale.MachineLearning.Classes
{
    /// <summary>
    /// Machine Learning Functions
    /// </summary>
    public class clsML
    {
        #region Regression
        /// <summary>
        /// Linear Regression
        /// </summary>
        /// <param name="test">Data to test</param>
        /// <param name="inputList">Learning inputs</param>
        /// <param name="outputList">Learning outputs</param>
        /// <returns>Result</returns>
        public double LinearRegression(double test, List<double> inputList, List<double> outputList, int seed)
        {

            // sample data
            double[] inputs = inputList.ToArray();
            double[] outputs = outputList.ToArray();
            Accord.Math.Random.Generator.Seed = seed;

            // Use Ordinary Least Squares with simple linear regression
            OrdinaryLeastSquares ols = new OrdinaryLeastSquares();
            SimpleLinearRegression regression = ols.Learn(inputs, outputs);

            double result = regression.Transform(test);

            return result;
        }

        /// <summary>
        /// Non Linear Regression
        /// </summary>
        /// <param name="test">Data to test</param>
        /// <param name="inputList">Learing inputs</param>
        /// <param name="outputList">Learning outputs</param>
        /// <param name="degree">Degree</param>
        /// <param name="complex">Complexity</param>
        /// <returns>Result</returns>
        public Tuple<double[], double[], double> SequentialMinimalOptimizationRegressionModel(List<List<double>> test, List<List<double>> inputList, List<double> outputList, double degree, double complex, int seed)
        {

            // Training data
            double[][] inputs = inputList.Select(a => a.ToArray()).ToArray();
            double[][] testdata = test.Select(a => a.ToArray()).ToArray();
            double[] outputs = outputList.ToArray();

            Accord.Math.Random.Generator.Seed = seed;

            // Create the sequential minimal optimization teacher
            var teacher = new SequentialMinimalOptimizationRegression() {
                Kernel = new Gaussian(degree),
                Complexity = complex
            };

            // Run the learning algorithm
            SupportVectorMachine<IKernel> svm = teacher.Learn(inputs, outputs);

            // Compute the predicted scores
            double[] predicted = svm.Score(testdata);

            // Compute the error between the expected and predicted
            double error = 0;
            try
            {
                error = new SquareLoss(outputs).Loss(predicted);
            }
            catch { }


            List<double> scores = new List<double>();
            foreach (double[] t in testdata)
            {
                double fxy = svm.Score(t);
                scores.Add(fxy);
            }
            double[] scrArr = scores.ToArray();

            return Tuple.Create<double[], double[], double>(predicted, scrArr, error);
        }

        /// <summary>
        /// Logistic Regression
        /// </summary>
        /// <param name="test">Data to test</param>
        /// <param name="inputList">Learning inputs</param>
        /// <param name="outputList">Learnout outputs</param>
        /// <returns>Result</returns>
        public Tuple<bool[], double[]> LogisticRegression(List<List<double>> test, List<List<double>> inputList, List<bool> outputList, double tolerance, int maxIter, double regular, int seed)
        {
            double[][] testdata = test.Select(a => a.ToArray()).ToArray();
            Accord.Math.Random.Generator.Seed = seed;

            // Training data
            double[][] input = inputList.Select(a => a.ToArray()).ToArray();
            bool[] output = outputList.ToArray();

            // Create a new Iterative Reweighted Least Squares algorithm
            var learner = new IterativeReweightedLeastSquares<LogisticRegression>() {
                Tolerance = tolerance,
                Iterations = maxIter,
                Regularization = 0
            };

            // Now, we can use the learner to finally estimate our model:
            LogisticRegression regression = learner.Learn(input, output);

            double[] score = regression.Probability(testdata);
            bool[] actual = regression.Decide(testdata);

            return Tuple.Create<bool[], double[]>(actual, score);
        }

        /// <summary>
        /// Multivariate Linear Regression
        /// </summary>
        /// <param name="testList">List to test</param>
        /// <param name="inputList">Learning inputs</param>
        /// <param name="outputList">Learning outputs</param>
        /// <returns>Result</returns>
        public double[][] MultivariateLinearRegression(List<List<double>> testList, List<List<double>> inputList, List<List<double>> outputList, int seed)
        {

            // Training data
            double[][] inputs = inputList.Select(a => a.ToArray()).ToArray();
            double[][] outputs = outputList.Select(a => a.ToArray()).ToArray();
            double[][] testinputs = testList.Select(a => a.ToArray()).ToArray();

            Accord.Math.Random.Generator.Seed = seed;

            // use ordinary least squares with multivariate linear regression
            OrdinaryLeastSquares ols = new OrdinaryLeastSquares();
            MultivariateLinearRegression regression = ols.Learn(inputs, outputs);

            double[][] predictions = regression.Transform(testinputs);
            return predictions;

        }
        #endregion

        #region Classification
        /// <summary>
        /// Naive Bayes Classifier
        /// </summary>
        /// <param name="test">Data to test</param>
        /// <param name="data">All data</param>
        /// <param name="inputColumns">Input columns for data</param>
        /// <param name="outputColumn">Ouput column</param>
        /// <returns>Result</returns>
        public Tuple<string, int, double[]> NaiveBayesClassifier(List<string> test, DataTable data, List<string> inputColumns, string outputColumn, int seed)
        {
            List<string> colNames = new List<string>();
            Accord.Math.Random.Generator.Seed = seed;

            foreach (DataColumn dc in data.Columns)
            {
                foreach (string input in inputColumns)
                {
                    if (input == dc.ColumnName)
                    {
                        colNames.Add(dc.ColumnName);
                    }
                }
                if (dc.ColumnName == outputColumn)
                {
                    colNames.Add(dc.ColumnName);
                }
            }
            string[] codes = colNames.ToArray();

            Codification codebook = new Codification(data, codes);

            // Extract input and output pairs to train
            DataTable symbols = codebook.Apply(data);
            int[][] inputs = symbols.ToJagged<int>(inputColumns.ToArray());
            int[] outputs = symbols.ToArray<int>(outputColumn);

            // Create a new Naive Bayes learning
            var learner = new NaiveBayesLearning();

            // Learn a Naive Bayes model from the examples
            NaiveBayes nb = learner.Learn(inputs, outputs);

            // Consider we would like to know whether one should play tennis at a
            // sunny, cool, humid and windy day. Let us first encode this instance
            int[] instance = codebook.Transform(test.ToArray());

            // Let us obtain the numeric output that represents the answer
            int c = nb.Decide(instance);
            string result = codebook.Revert(outputColumn, c);
            double[] probs = nb.Probabilities(instance);

            return Tuple.Create<string, int, double[]>(result, c, probs);
        }

        /// <summary>
        /// Adaptive Naive Bayes Classifier
        /// </summary>
        /// <param name="inputList">Input List</param>
        /// <param name="outputList">Output List</param>
        /// <returns>Result</returns>
        public NaiveBayes<NormalDistribution> AdaptiveNaiveBayesClassifier(List<List<double>> inputList, List<int> outputList)
        {
            double[][] inputs = inputList.Select(a => a.ToArray()).ToArray();
            int[] outputs = outputList.ToArray();

            // Create the Bayes classifier and perform classification
            var teacher = new NaiveBayesLearning<NormalDistribution>();

            NaiveBayes<NormalDistribution> bayes = teacher.Learn(inputs, outputs);

            return bayes;
        }

        /// <summary>
        /// Adaptive Naive Bayes Classifier
        /// </summary>
        /// <param name="inputList">Input List</param>
        /// <param name="outputList">Output List</param>
        /// <returns>Result</returns>
        public List<int> NaiveBayesDecision(NaiveBayes<NormalDistribution> naiveBayes, List<List<double>> inputList)
        {
            double[][] inputs = inputList.Select(a => a.ToArray()).ToArray();

            int[] classifications = naiveBayes.Decide(inputs);
            return classifications.ToList();

        }

        /// <summary>
        /// Gaussian Mixture Classifier
        /// </summary>
        /// <param name="inputList">Learning samples</param>
        /// <param name="components">Components</param>
        /// <returns>Result</returns>
        public Tuple<int[], double[], double[][]> GaussianMixture(List<List<double>> inputList, int coms, int seed)
        {
            // Test Samples
            double[][] inputData = inputList.Select(a => a.ToArray()).ToArray();
            Accord.Math.Random.Generator.Seed = seed;

            //MultivariateNormalDistribution[] components = new MultivariateNormalDistribution[coms];
            //for (int i = 0; i < coms; i++)
            //{
            //    MultivariateNormalDistribution mnd = new MultivariateNormalDistribution(inputData[i].Count());
            //    components[i] = mnd;
            //}

            //MixtureOptions fittingOptions = new MixtureOptions()
            //{
            //    InnerOptions = new NormalOptions()
            //    {
            //        Regularization = 1e-10
            //    },
            //};

            //MultivariateMixture<MultivariateNormalDistribution> mixture = new MultivariateMixture<MultivariateNormalDistribution>(components);

            //mixture.Fit(inputData, fittingOptions);
            //GaussianMixtureModel gmm = new GaussianMixtureModel(mixture);

            GaussianMixtureModel gmm2 = new GaussianMixtureModel(coms);
            // Estimate the Gaussian Mixture
            var clusters = gmm2.Learn(inputData);

            // Predict cluster labels for each sample
            int[] predicted = clusters.Decide(inputData);
            double[] proportions = clusters.Proportions;
            double[][] variance = clusters.Variance;

            return Tuple.Create<int[], double[], double[][]>(predicted, proportions, variance);
        }

        /// <summary>
        /// K-Means Clustering
        /// </summary>
        /// <param name="inputList">Learning samples</param>
        /// <param name="components">Components</param>
        /// <returns>Result</returns>
        public Tuple<int[], double[], double[][]> KMeansClustering(List<List<double>> inputList, int coms, int seed)
        {
            // Test Samples
            double[][] inputData = inputList.Select(a => a.ToArray()).ToArray();
            Accord.Math.Random.Generator.Seed = seed;

            KMeans kmkean = new KMeans(coms);
            // Estimate the Gaussian Mixture
            var clusters = kmkean.Learn(inputData);

            // Predict cluster labels for each sample
            int[] predicted = clusters.Decide(inputData);
            double[] proportions = clusters.Proportions;
            double[][] centroids = clusters.Centroids;

            return Tuple.Create<int[], double[], double[][]>(predicted, proportions, centroids);
        }
        #endregion

        #region Networks
        /// <summary>
        /// Neural Network
        /// </summary>
        /// <param name="test">Test</param>
        /// <param name="inputList">Input list</param>
        /// <param name="labelList">Label list</param>
        /// <param name="hiddenNeurons">Hidden neurons</param>
        /// <param name="teach">teach</param>
        /// <returns>Result</returns>
        public string[] NeuralNetwork(List<List<double>> test, List<List<double>> inputList, List<int> labelList, int hiddenNeurons, double alpha, int iterations, int seed)
        {

            int[] labels = labelList.ToArray();
            double[][] input = inputList.Select(a => a.ToArray()).ToArray();
            double[][] testinput = test.Select(a => a.ToArray()).ToArray();

            Accord.Math.Random.Generator.Seed = seed;

            int numberOfInputs = testinput[0].Length;
            int[] MyDistinctArray = labels.Distinct();
            int numberOfClasses = MyDistinctArray.Length;

            double[][] outputs = Accord.Math.Jagged.OneHot(labels);

            // Next we can proceed to create our network
            var function = new BipolarSigmoidFunction(alpha);
            var network = new ActivationNetwork(function,
              numberOfInputs, hiddenNeurons, numberOfClasses);

            // Heuristically randomize the network
            new NguyenWidrow(network).Randomize();

            // Create the learning algorithm
            var teacher = new LevenbergMarquardtLearning(network);

            // Teach the network for 10 iterations:
            double error = Double.PositiveInfinity;
            for (int i = 0; i < iterations; i++)
                error = teacher.RunEpoch(input, outputs);

            // At this point, the network should be able to 
            // perfectly classify the training input points.
            List<string> strList = new List<string>();
            for (int i = 0; i < testinput.Length; i++)
            {
                int answer;
                double[] output = network.Compute(testinput[i]);
                double response = output.Max(out answer);

                //int expected = labels[i];
                strList.Add(answer.ToString());

                // at this point, the variables 'answer' and
                // 'expected' should contain the same value.
            }
            string[] results = strList.ToArray();
            return results;

        }

        //建立简单的神经网络
        public ActivationNetwork createNetwork( List<List<double>> inputList, List<int> labelList, int hiddenNeurons, double alpha, int iterations, int seed, ref List<double> errorRate)
        {
            int[] labels = labelList.ToArray();
            double[][] input = inputList.Select(a => a.ToArray()).ToArray();

            Accord.Math.Random.Generator.Seed = seed;

            int numberOfInputs = input[0].Length;
            int[] MyDistinctArray = labels.Distinct();
            int numberOfClasses = MyDistinctArray.Length;

            double[][] outputs = Accord.Math.Jagged.OneHot(labels);

            // Next we can proceed to create our network
            var function = new BipolarSigmoidFunction(alpha);
            var network = new ActivationNetwork(function,
              numberOfInputs, hiddenNeurons, numberOfClasses);

            // Heuristically randomize the network
            new NguyenWidrow(network).Randomize();

            // Create the learning algorithm
            var teacher = new LevenbergMarquardtLearning(network);

            // Teach the network for 10 iterations:
            double error = Double.PositiveInfinity;
            for (int i = 0; i < iterations; i++)
            {
                error = teacher.RunEpoch(input, outputs);
                errorRate.Add(error);
            }
               

            return network;
        }

        //预测
        public string[] predictResult(List<List<double>> test, ActivationNetwork network)
        {
            double[][] testinput = test.Select(a => a.ToArray()).ToArray();

            // At this point, the network should be able to 
            // perfectly classify the training input points.
            List<string> strList = new List<string>();
            for (int i = 0; i < testinput.Length; i++)
            {
                int answer;
                double[] output = network.Compute(testinput[i]);
                double response = output.Max(out answer);

                //int expected = labels[i];
                strList.Add(answer.ToString());

                // at this point, the variables 'answer' and
                // 'expected' should contain the same value.
            }
            string[] results = strList.ToArray();
            return results;
        }

        /// <summary>
        /// Backpropagation Network Trainer
        /// </summary>
        /// <param name="inputList">Input List</param>
        /// <param name="outputList">Output List</param>
        /// <param name="numOfInputNeurons">Number of Input Neurons</param>
        /// <param name="numOfHiddenNeurons">Number of Hidden Neurons</param>
        /// <param name="learningRate">Learning Rate</param>
        /// <param name="alpha">Sigmoid Alpha Value</param>
        /// <param name="numOfIterations">Number of Iterations</param>
        /// <param name="errorRate">Error Rate</param>
        /// <returns>Result Neural Network</returns>
        public ActivationNetwork BackPropagationTrainer(List<List<double>> inputList, List<List<double>> outputList, LearningAlgorithm learningAlgorithm, ActivationFunction activationFunction, List<int> numOfHiddenNeurons, double alpha, int numOfIterations, double learningRate, double momentum, int chromosomes, bool useRegularization, double adjustment, double bayesianAlpha, double bayesianBeta, ref List<double> errorRate)
        {
            bool useNguyenWidrow = false;
            double[][] input = inputList.Select(a => a.ToArray()).ToArray();
            double[][] output = outputList.Select(a => a.ToArray()).ToArray();

            int numOfInputNeurons = input[0].Length;
            int numOfOutputNeurons = output[0].Length;
            if (numOfHiddenNeurons.Count <= 0)
            {
                numOfHiddenNeurons.Clear();
                numOfHiddenNeurons.Add(1);
            }

            // Create Network Layer Structure
            int[] layers = new int[numOfHiddenNeurons.Count + 1];
            for (int i = 0; i < numOfHiddenNeurons.Count; i++)
            {
                layers[i] = numOfHiddenNeurons[i];
            }
            layers[numOfHiddenNeurons.Count] = numOfOutputNeurons;

            if (learningRate <= 0.0) learningRate = 0.0;
            else if (learningRate >= 1.0) learningRate = 1.0;

            if (momentum <= 0.0) momentum = 0.0;
            else if (momentum >= 1.0) momentum = 1.0;

            // create multi-layer neural network
            ActivationNetwork network = new ActivationNetwork(createActivationFunction(activationFunction, alpha), numOfInputNeurons, layers);

            if (useNguyenWidrow)
            {
                new NguyenWidrow(network).Randomize();
            }

            // create teacher
            var teacher = createLearningAlgorithm(learningAlgorithm, ref network, learningRate, momentum, chromosomes, useRegularization, adjustment, bayesianAlpha, bayesianBeta);

            // iterations
            int iteration = 0;

            while (iteration <= numOfIterations)
            {
                // run epoch of learning procedure
                double error = teacher.RunEpoch(input, output) / numOfIterations;

                errorRate.Add(error);

                // increase current iteration
                iteration++;
            }

            return network;
        }

        private IActivationFunction createActivationFunction(ActivationFunction function, double alpha)
        {

            if (function == ActivationFunction.Sigmoid)
            {
                return new SigmoidFunction(alpha);
            }
            else if (function == ActivationFunction.BipolarSigmoid)
            {
                return new BipolarSigmoidFunction(alpha);
            }
            else if (function == ActivationFunction.Linear)
            {
                return new LinearFunction(alpha);
            }
            else if (function == ActivationFunction.RectifiedLinear)
            {
                return new RectifiedLinearFunction();
            }
            else if (function == ActivationFunction.Threshold)
            {
                return new ThresholdFunction();
            }
            else if (function == ActivationFunction.Identity)
            {
                return new IdentityFunction();
            }
            else
            {
                return null;
            }
        }

        private Accord.Neuro.Learning.ISupervisedLearning createLearningAlgorithm(LearningAlgorithm learningAlgorithm, ref ActivationNetwork network, double learningRate, double momentum, int chromosomes, bool useRegularization, double adjustment, double bayesianAlpha, double bayesianBeta)
        {

            if (learningAlgorithm == LearningAlgorithm.Backpropagation)
            {
                BackPropagationLearning learner = new BackPropagationLearning(network);
                learner.LearningRate = learningRate;
                learner.Momentum = momentum;
                return learner;
            }
            else if (learningAlgorithm == LearningAlgorithm.ResilientBackpropagation)
            {
                return new ParallelResilientBackpropagationLearning(network);
            }
            else if (learningAlgorithm == LearningAlgorithm.Evolutionary)
            {
                return new EvolutionaryLearning(network, chromosomes);
            }
            else if (learningAlgorithm == LearningAlgorithm.LevenbergMarquardt)
            {
                LevenbergMarquardtLearning learner = new LevenbergMarquardtLearning(network);
                learner.UseRegularization = useRegularization;
                learner.Adjustment = adjustment;
                learner.LearningRate = learningRate;
                learner.Alpha = bayesianAlpha;
                learner.Beta = bayesianBeta;
                return learner;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Backpropagation Network Tester
        /// </summary>
        /// <param name="network">Trained Neural Network</param>
        /// <param name="inputList">Input List</param>
        /// <returns>Predicted Output</returns>
        public double[][] BackPropagationTester(ActivationNetwork network, List<List<double>> inputList)
        {
            double[][] input = inputList.Select(a => a.ToArray()).ToArray();
            int count = input.GetLength(0);
            double[][] outputList = new double[count][];

            for (int i = 0; i < count; i++)
            {
                double[] output = network.Compute(input[i]);
                outputList[i] = output;
            }
            return outputList;
        }

        /// <summary>
        /// Restricted Boltzmann Soliver
        /// </summary>
        /// <param name="testList">Test list</param>
        /// <param name="inputList">Learning inputs</param>
        /// <param name="outputList">Learning outputs</param>
        /// <returns>Result</returns>
        public double[] RestrictedBoltzmann(List<double> testList, List<List<double>> inputList, List<List<double>> outputList, double momentum, double learningrate, double decay, double alpha, int iterations, int seed)
        {

            // Training data
            double[][] inputs = inputList.Select(j => j.ToArray()).ToArray();
            double[][] outputs = outputList.Select(k => k.ToArray()).ToArray();
            double[] test = testList.ToArray();

            Accord.Math.Random.Generator.Seed = seed;

            // Create a Bernoulli activation function
            var function = new BernoulliFunction(alpha: alpha);


            int inputsCount = inputs[0].Length;
            int hiddenNeurons = outputs[0].Length;
            //int inputsCount = inputs[0].Length;
            //int hiddenNeurons = outputs[0].Length;
            // Create a Restricted Boltzmann Machine for 6 inputs and with 1 hidden neuron
            var rbm = new RestrictedBoltzmannMachine(function, inputsCount, hiddenNeurons);

            // Create the learning algorithm for RBMs
            var teacher = new ContrastiveDivergenceLearning(rbm) {
                Momentum = momentum,
                LearningRate = learningrate,
                Decay = decay
            };

            // learn 5000 iterations
            for (int i = 0; i < iterations; i++)
                teacher.RunEpoch(inputs);

            // Compute the machine answers for the given inputs:
            double[] a = rbm.Compute(test);
            return a;
        }
        #endregion

        #region Models
        /// <summary>
        /// Hidden Markov Model
        /// </summary>
        /// <param name="inputList">Input list</param>
        /// <param name="num">Number</param>
        /// <returns>Result</returns>
        public string[] HiddenMarkovModel(List<List<string>> inputList, int num, int seed, int stateNum)
        {
            string[][] inputs = inputList.Select(a => a.ToArray()).ToArray();
            Accord.Math.Random.Generator.Seed = seed;

            var codebook = new Codification("Data", inputs);

            int[][] sequence = codebook.Transform("Data", inputs);

            var topology = new Forward(states: stateNum);
            int symbols = codebook["Data"].NumberOfSymbols;

            var hmm = new HiddenMarkovModel(topology, symbols);

            var teacher = new BaumWelchLearning(hmm);

            teacher.Learn(sequence);

            int[] sample = hmm.Generate(num);

            string[] result = codebook.Revert("Data", sample);

            return result;
        }
        #endregion
    }
}
