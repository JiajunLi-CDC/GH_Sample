﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

using Grasshopper.Kernel;
using Grasshopper.Kernel.Data;
using Grasshopper.Kernel.Types;

using CurlyKale.MachineLearning.Classes;

namespace CurlyKale.MachineLearning
{
    /// <summary>
    /// Neural Network Node
    /// </summary>
    public class nodeSimpleNeuralNetworkTesting : GH_Component
    {
        #region Register Node

        /// <summary>
        /// Load Node Template
        /// </summary>
        public nodeSimpleNeuralNetworkTesting()
            : base("Simple Neural Network Tester", "Simple Neural Network Tester", "Test a solution using a trained neural network solver.", "CurlyKale", "06 MachineLearning")
        {

        }

        /// <summary>
        /// Component Exposure
        /// </summary>
        public override GH_Exposure Exposure
        {
            get
            {
                return GH_Exposure.quarternary;
            }
        }

        /// <summary>
        /// GUID generator http://www.guidgenerator.com/online-guid-generator.aspx
        /// </summary>
        public override Guid ComponentGuid
        {
            get
            {
                return new Guid("75157d8d-81a3-44b5-886c-1e157c42236c");
            }
        }

        /// <summary>
        /// Icon 24x24
        /// </summary>
        protected override Bitmap Icon
        {
            get
            {
                return Properties.Resources.PG_ML_NeuralNetwork_Tester;
            }
        }
        #endregion

        #region Inputs/Outputs
        /// <summary>
        /// Node inputs
        /// </summary>
        /// <param name="pManager"></param>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddGenericParameter("Trained Neural Network", "Neural Network", "A trained neural network.", GH_ParamAccess.item);
            pManager.AddNumberParameter("Test Input Data", "Input", "Test input data. Assumes values have been remapped to [-1 to 1] domain.", GH_ParamAccess.tree);
        }

        /// <summary>
        /// Node outputs
        /// </summary>
        /// <param name="pManager"></param>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.Register_GenericParam("Result", "Result", "Resultant prediction");
        }
        #endregion

        #region Solution
        /// <summary>
        /// Code by the component
        /// </summary>
        /// <param name="DA"></param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            // Tree Structure Input Variables         
            GH_Structure<GH_Number> inputs = new GH_Structure<GH_Number>();
            GH_ObjectWrapper m_network = new GH_ObjectWrapper();

            //Tree Variables
            if (
                    DA.GetData<GH_ObjectWrapper>(0, ref m_network) &&
                    DA.GetDataTree<GH_Number>(1, out inputs)
                )
            {

                try
                {
                    Accord.Neuro.ActivationNetwork network = m_network.Value as Accord.Neuro.ActivationNetwork;
                    List<List<double>> inputList = new List<List<double>>();

                    for (int i = 0; i < inputs.Branches.Count; i++)
                    {
                        List<double> list = new List<double>();
                        List<GH_Number> branch = inputs.Branches[i];
                        foreach (GH_Number num in branch)
                        {
                            list.Add(num.Value);
                        }
                        inputList.Add(list);
                    }

                    //Result
                    clsML ML = new Classes.clsML();
                    string[] result = ML.predictResult(inputList, network);

                    //Output
                    DA.SetDataList(0, result.ToList());
                }
                catch (InvalidCastException e)
                {
                    AddRuntimeMessage(GH_RuntimeMessageLevel.Warning, e.Message.ToString());
                }



            }
        }
        #endregion
    }
}



